(() => {
 'use strict';
 if(parent===window)return;
 const file=location.pathname.split('/').pop();
 if(file==='planet-01.html'&&!location.search.includes('embed')){const u=new URL(location.href);u.searchParams.set('embed','1');history.replaceState(null,'',u);}
 const send=data=>parent.postMessage({station:'projector',file,...data},'*');
 let startRequested=false,firstBeat=true,resumeAt=0,sceneReady=false,pendingSound=null;

 function checkpoint(){
  const resume={localStorage:{},sessionStorage:{}};
  for(const name of Object.keys(resume)){
   try{
    const storage=window[name];
    for(const key of Object.keys(storage)){
     if(!/^(terra-incognita[:_]|beyond-known:|ti_|fh_)/.test(key))continue;
     const value=storage.getItem(key);
     if(value!==null&&value.length<250000)resume[name][key]=value;
    }
   }catch{}
  }
  return resume;
 }

 function applySound(){
  if(pendingSound===null||!sceneReady||file==='index.html')return;
  const button=document.querySelector('#ti-sound,#sound');
  if(!button||button.disabled)return;
  const state=button.dataset.audioState;
  // The planet's START and RESUME buttons report aria-pressed before playback.
  // A click in either state starts audio; wait for playback if muting it.
  if(!pendingSound&&(state==='start'||state==='resume'))return;
  const on=state ? state==='on' : button.getAttribute('aria-pressed')==='true';
  const enabled=pendingSound;
  pendingSound=null;
  if(on!==enabled)button.click();
 }
 const timer=setInterval(()=>{
  let ready=false,phase='',seconds=0,token='';
  try{
   if(file==='index.html'){
    const button=document.querySelector('#ti-start');ready=!!window.TI_BLUEPRINT;token=String(window.TI_BLUEPRINT?.().draws??'');
    if(button&&!button.disabled&&!startRequested){startRequested=true;button.click();}
   }else if(window.TI_SEQUENCE){const s=TI_SEQUENCE(),p=window.TI_EXPERIENCE?.().position;ready=!!window.TI_READY;phase=[s.world,s.mission,s.prologue,s.docking,s.voyage].join(' / ');token=JSON.stringify([s,p&&[p.x.toFixed(3),p.z.toFixed(3)],window.TI_CAMERA?.().shot]);}
   else if(window.BTK_SPACE){const s=BTK_SPACE.snapshot();ready=true;seconds=s.seconds;phase=s.shot;}
   else if(window.CANDIDATE?.ready){const s=CANDIDATE.snapshot();ready=true;seconds=s.seconds;phase=s.phase;}
   else if(window.BTK_ENDING){const s=BTK_ENDING.snapshot();ready=true;seconds=s.seconds;phase='ending';}
   else if(window.FIRST_DAWN){const s=FIRST_DAWN.snapshot();ready=true;seconds=s.seconds;phase=s.phase||s.shot;}
   sceneReady=ready;
   applySound();
   if(seconds)token=seconds.toFixed(2);
   const beat={type:'heartbeat',ready,phase,seconds,token,firstBeat};
   const now=Date.now();
   if(firstBeat||now-resumeAt>=15000){resumeAt=now;beat.resume=checkpoint();}
   send(beat);
   firstBeat=false;
  }catch(e){send({type:'error',message:String(e)});}
 },1000);
 addEventListener('message',e=>{
  if(e.source!==parent||e.data?.station!=='projector-command')return;
  if(e.data.action==='reload'){location.reload();return;}
  if(e.data.action==='sound'){
   pendingSound=!!e.data.enabled;
   try{sessionStorage.setItem('ti_audio_muted',pendingSound?'0':'1');}catch{}
   applySound();
  }
 });
 addEventListener('keydown',e=>{if(e.metaKey)return;e.preventDefault();e.stopImmediatePropagation();if(['KeyO','KeyF','Escape'].includes(e.code))send({type:'key',code:e.code});},true);
 addEventListener('error',e=>send({type:'error',message:e.message}));
 addEventListener('pagehide',()=>clearInterval(timer));
})();
