(() => {
 'use strict';
 const frame=document.getElementById('screen'),veil=document.getElementById('veil'),panel=document.getElementById('operator'),status=document.getElementById('status'),error=document.getElementById('error');
 const query=new URLSearchParams(location.search),quality=['high','mid','low'].includes(query.get('quality'))?query.get('quality'):'mid';
 const files=['index.html','planet-01.html','space-01.html','planet-02.html','space-02.html','planet-03.html','space-03.html','planet-04.html','migration.html','arrival.html','ending.html'];
 let cycle=0,started=Date.now(),lastBeat=Date.now(),lastProgress=Date.now(),lastToken='',lastFile='',lastData=null,retries=0,looping=false,resetting=false,blocked=false,sound=false,watchdog=null,transitionTimer=null;
 const events=[];
 function record(type,data={}){events.push({at:new Date().toISOString(),type,...data});if(events.length>300)events.shift();}
 async function resetRun(){for(const storage of [localStorage,sessionStorage]){for(const key of Object.keys(storage)){if(/^(terra-incognita[:_]|beyond-known:|ti_|fh_)/.test(key))storage.removeItem(key);}}
  sessionStorage.setItem('ti_audio_muted',sound?'0':'1');
  // Projector cycles each show a new settlement. The iMac keeps its own memory.
  await new Promise((resolve,reject)=>{let settled=false,db=null,tx=null;const finish=e=>{if(settled)return;settled=true;clearTimeout(timeout);db?.close();e?reject(e):resolve();};const timeout=setTimeout(()=>{try{tx?.abort();}catch{}finish(new Error('저장소가 응답하지 않습니다. 다른 전시 창을 닫은 뒤 처음부터 다시 실행해 주세요.'));},10000);const request=indexedDB.open('beyond-known-place-v1',1);request.onblocked=()=>finish(new Error('다른 전시 창에서 저장소를 사용하고 있습니다. 해당 창을 닫고 처음부터 다시 실행해 주세요.'));request.onupgradeneeded=()=>{if(settled){request.transaction.abort();return;}for(const name of ['world','frames','vehicles'])if(!request.result.objectStoreNames.contains(name))request.result.createObjectStore(name,{keyPath:'id'});};request.onerror=()=>finish(request.error);request.onsuccess=()=>{db=request.result;if(settled){db.close();return;}try{tx=db.transaction(['world','frames','vehicles'],'readwrite');for(const name of ['world','frames','vehicles'])tx.objectStore(name).clear();tx.oncomplete=()=>finish();tx.onerror=tx.onabort=()=>finish(tx.error||new Error('전시 상태를 초기화하지 못했습니다.'));}catch(e){finish(e);}};});
 }
 async function start(){if(resetting)return;if(transitionTimer){clearTimeout(transitionTimer);transitionTimer=null;}resetting=looping=true;blocked=false;error.textContent='';veil.classList.add('on');try{await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>{frame.onload=null;reject(new Error('화면을 닫지 못했습니다. 전시 프로그램을 다시 실행해 주세요.'));},10000);frame.onload=()=>{clearTimeout(timeout);frame.onload=null;resolve();};frame.src='about:blank';});await resetRun();cycle++;started=Date.now();lastBeat=lastProgress=Date.now();lastToken='';lastFile='';lastData=null;retries=0;record('cycle',{cycle});frame.src=`works/index.html?quality=${quality}&full&exhibition=projector`;}catch(e){blocked=true;error.textContent=String(e);operator(true);record('reset-error',{message:String(e)});}finally{resetting=looping=false;}}
 function reloadScene(manual=false){if(resetting||looping)return;if(manual&&events.at(-1)?.type==='reset-error'){start();return;}if(manual){blocked=false;retries=0;error.textContent='';}let url=new URL(`works/${lastFile||'index.html'}?quality=${quality}&full&exhibition=projector`,location.href);try{const current=new URL(frame.contentWindow.location.href);if(current.href.startsWith(new URL('works/',location.href).href)&&files.includes(current.pathname.split('/').pop()))url=current;}catch{}lastBeat=lastProgress=Date.now();veil.classList.add('on');record(manual?'manual-recovery':'reload',{file:url.pathname.split('/').pop()});frame.src=url.href;}
 function operator(show){panel.hidden=!show;document.body.classList.toggle('operator',show);}
 function fullscreen(){document.documentElement.requestFullscreen?.().catch(()=>{});}
 function sendSound(){frame.contentWindow?.postMessage({station:'projector-command',action:'sound',enabled:sound},'*');}
 function audio(){sound=!sound;document.getElementById('sound').textContent=sound?'소리 끄기':'소리 켜기';sendSound();}
 function key(e){if(e.code==='KeyO')operator(panel.hidden);if(e.code==='KeyF')fullscreen();if(e.code==='Escape')operator(false);}
 addEventListener('keydown',key);
 addEventListener('message',e=>{
  if(e.source!==frame.contentWindow||e.data?.station!=='projector'||resetting)return;
  try{if(frame.contentWindow.location.pathname.split('/').pop()!==e.data.file)return;}catch{return;}
  const d=e.data;if(d.type==='key'){key(d);return;}if(d.type==='error'){record('error',{message:d.message});error.textContent=d.message;operator(true);return;}
  if(d.type!=='heartbeat'||!files.includes(d.file))return;
  const newScene=lastFile!==d.file;
  lastBeat=Date.now();
  if(!newScene&&!d.resume&&lastData?.resume)d.resume=lastData.resume;
  lastData=d;
  if(newScene){lastFile=d.file;lastProgress=Date.now();lastToken='';retries=0;record('scene',{file:d.file,elapsed:(Date.now()-started)/1000});}
  if(newScene||d.firstBeat)sendSound();
  if(d.ready&&d.token&&d.token!==lastToken){lastProgress=Date.now();lastToken=d.token;}
  status.textContent=`${cycle}회 · ${d.file} · ${Math.floor((Date.now()-started)/60000)}분 ${Math.floor((Date.now()-started)/1000)%60}초 · ${d.phase||''}`;
  if(d.file==='ending.html'&&d.seconds>=30&&!looping){looping=true;record('complete',{durationSeconds:(Date.now()-started)/1000});veil.classList.add('on');transitionTimer=setTimeout(start,6500);}
  if(d.ready&&!looping)veil.classList.remove('on');
 });
 document.getElementById('fullscreen').onclick=fullscreen;document.getElementById('sound').onclick=audio;document.getElementById('restart').onclick=start;document.getElementById('retry').onclick=()=>reloadScene(true);
 watchdog=setInterval(()=>{if(document.hidden||looping||blocked||(Date.now()-lastBeat<90000&&Date.now()-lastProgress<120000))return;lastBeat=lastProgress=Date.now();record('recovery',{file:lastFile||'index.html',retry:++retries});if(retries<=2){reloadScene();}else{blocked=true;error.textContent='작품의 실행 상태를 확인해 주세요. 같은 장면을 다시 열거나 처음부터 시작할 수 있습니다.';operator(true);}},5000);
 window.PROJECTOR={snapshot:()=>({cycle,quality,file:lastFile,elapsed:(Date.now()-started)/1000,lastData,events:[...events],looping}),restart:start};
 addEventListener('visibilitychange',()=>{lastBeat=lastProgress=Date.now();});addEventListener('pagehide',()=>clearInterval(watchdog));
 if(query.has('operator'))operator(true);start();
})();
