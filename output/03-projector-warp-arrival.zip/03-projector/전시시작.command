#!/bin/zsh
unsetopt BG_NICE
cd -- "${0:A:h}" || exit 1
station_root="$PWD"
chrome_bin="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
if [[ ! -x "$chrome_bin" ]]; then
  /usr/bin/osascript -e 'display dialog "Google Chrome을 설치한 뒤 다시 실행해 주세요." buttons {"확인"} default button 1'
  exit 1
fi
station_profile="$HOME/Library/Application Support/BeyondTheKnown/projector"
mkdir -p "$station_profile" || exit 1
station_url=$(/usr/bin/osascript -l JavaScript -e 'ObjC.import("Foundation"); function run(argv) { return $.NSURL.fileURLWithPath(argv[0]).absoluteString.js; }' "$station_root/index.html") || exit 1
print '전시 실행 중 · 종료: Command + Q'
print '이 창을 닫지 마세요. 화면 절전을 막고 있습니다.'
"$chrome_bin" --user-data-dir="$station_profile" --no-first-run --no-default-browser-check --allow-file-access-from-files --autoplay-policy=no-user-gesture-required --kiosk "$station_url" &
station_pid=$!
/usr/bin/caffeinate -di -w "$station_pid"
wait "$station_pid"
